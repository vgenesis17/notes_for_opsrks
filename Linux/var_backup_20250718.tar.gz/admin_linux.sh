#!/bin/bash


tar -cvf archive.tar /var

date=$(date +%Y%m%d%)


